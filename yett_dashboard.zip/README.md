# 📊 Dashboard Triển khai Yett Demi Menthol

Dashboard tự động từ file Excel, deploy miễn phí lên Streamlit Cloud.

---

## 🚀 Deploy lên Streamlit Cloud (Free, ~5 phút)

### Bước 1 — Tạo tài khoản GitHub (nếu chưa có)
Vào [github.com](https://github.com) → Sign up (miễn phí)

### Bước 2 — Tạo repository mới
1. Click **"New repository"**
2. Đặt tên: `yett-dashboard`
3. Để **Public**
4. Click **Create repository**

### Bước 3 — Upload 2 file này lên repo
Upload `app.py` và `requirements.txt` vào repo vừa tạo

### Bước 4 — Deploy lên Streamlit Cloud
1. Vào [share.streamlit.io](https://share.streamlit.io)
2. Đăng nhập bằng GitHub
3. Click **"New app"**
4. Chọn repo `yett-dashboard`, file `app.py`
5. Click **Deploy** → đợi ~1 phút

✅ **Xong!** Bạn nhận được link dạng:  
`https://yourusername-yett-dashboard-app-xxxxx.streamlit.app`

Gửi link này cho cả team — ai cũng xem được, không cần tài khoản.

---

## 📂 Cách sử dụng hàng ngày

1. Export file Excel từ DMS (cấu trúc 4 sheet như cũ)
2. Vào link dashboard → Upload file mới
3. Dashboard cập nhật ngay lập tức

---

## 📋 Cấu trúc file Excel cần có

| Sheet | Mô tả |
|---|---|
| `Tom tat` | KPI theo Miền (header row 3) |
| `Tong hop Mien-Tinh` | Tổng hợp Miền × Tỉnh (header row 3) |
| `Theo NVTT` | Chi tiết theo NVTT (header row 4) |
| `Thong ke_Mua lai` | Thống kê điểm bán mua lại (header row 1) |
