import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from io import BytesIO

st.set_page_config(
    page_title="Triển khai Yett Demi Menthol",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# ── Custom CSS ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&display=swap');

html, body, [class*="css"] { font-family: 'Be Vietnam Pro', sans-serif; }

.block-container { padding: 1.5rem 2rem 2rem; }

.metric-card {
    background: #fff;
    border: 1px solid #e8eaf0;
    border-radius: 12px;
    padding: 18px 22px;
    border-left: 4px solid #1a56db;
}
.metric-card.warn  { border-left-color: #e3a008; }
.metric-card.good  { border-left-color: #0e9f6e; }
.metric-card.info  { border-left-color: #7e3af2; }
.metric-label { font-size: 12px; color: #6b7280; font-weight: 500; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 4px; }
.metric-value { font-size: 28px; font-weight: 700; color: #111827; line-height: 1; }
.metric-sub   { font-size: 12px; color: #9ca3af; margin-top: 4px; }

.kpi-badge-dat   { background: #d1fae5; color: #065f46; padding: 2px 10px; border-radius: 99px; font-size: 12px; font-weight: 600; }
.kpi-badge-chua  { background: #fee2e2; color: #991b1b; padding: 2px 10px; border-radius: 99px; font-size: 12px; font-weight: 600; }

.section-title { font-size: 18px; font-weight: 700; color: #1e3a5f; margin: 8px 0 16px; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px; }
.date-badge { background: #eff6ff; color: #1d4ed8; padding: 6px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; display: inline-block; margin-bottom: 16px; }
</style>
""", unsafe_allow_html=True)

# ── Header ──────────────────────────────────────────────────────────────────
st.markdown("## 📊 Triển khai Sản phẩm Yett Demi Menthol — GĐ1 KPI")
st.markdown("**Mốc KPI:** Bao phủ ≥30% tổng điểm quản lý của NVTT")

# ── File uploader ────────────────────────────────────────────────────────────
uploaded = st.file_uploader(
    "📂 Upload file báo cáo (.xlsx)",
    type=["xlsx"],
    help="Upload file Excel có 4 sheet: Tom tat, Tong hop Mien-Tinh, Theo NVTT, Thong ke_Mua lai"
)

if not uploaded:
    st.info("👆 Upload file Excel để xem dashboard. File mẫu có cấu trúc 4 sheet chuẩn.")
    st.stop()

# ── Load data ────────────────────────────────────────────────────────────────
@st.cache_data(show_spinner="Đang đọc dữ liệu...")
def load_data(file_bytes):
    xls = pd.ExcelFile(BytesIO(file_bytes))
    df_tom   = pd.read_excel(xls, sheet_name="Tom tat",            header=2)
    df_mien  = pd.read_excel(xls, sheet_name="Tong hop Mien-Tinh", header=2)
    df_nvtt  = pd.read_excel(xls, sheet_name="Theo NVTT",          header=3)
    df_mualai= pd.read_excel(xls, sheet_name="Thong ke_Mua lai",   header=0)
    return df_tom, df_mien, df_nvtt, df_mualai

file_bytes = uploaded.read()
df_tom, df_mien, df_nvtt, df_mualai = load_data(file_bytes)

# Clean
df_tom   = df_tom.dropna(subset=[df_tom.columns[0]])
df_mien  = df_mien.dropna(subset=[df_mien.columns[0]])
df_nvtt  = df_nvtt.dropna(subset=[df_nvtt.columns[0]])

# Detect date from subtitle
try:
    xls_raw = pd.ExcelFile(BytesIO(file_bytes))
    ws_raw  = pd.read_excel(xls_raw, sheet_name="Theo NVTT", header=None, nrows=3)
    subtitle = str(ws_raw.iloc[1,0])
    date_str = subtitle if subtitle != "nan" else ""
except: date_str = ""

# ── Tabs ─────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs(["📌 Tóm tắt KPI", "🗺️ Miền – Tỉnh", "👤 Theo NVTT", "🔁 Thống kê Mua lại"])

# ════════════════════════════════════════════════════════════════════════════
# TAB 1 – Tóm tắt KPI
# ════════════════════════════════════════════════════════════════════════════
with tab1:
    if date_str:
        st.markdown(f'<div class="date-badge">🗓️ {date_str}</div>', unsafe_allow_html=True)

    cols = df_tom.columns.tolist()
    # Standardize col names
    df_tom.columns = ["Miền","TongDiem","DiemBan","TyLeBaoPhu","DatKPI","SanLuong","SLBQ","DiemMuaLai","TyLeMuaLai"]

    # Grand total row
    total = df_tom.iloc[-1] if str(df_tom.iloc[-1,0]).upper() in ("TOÀN QUỐC","TOTAL","TỔNG CỘNG","GRAND TOTAL") \
            else df_tom.agg({"TongDiem":"sum","DiemBan":"sum","SanLuong":"sum","DiemMuaLai":"sum"}).to_dict()
    mien_data = df_tom[~df_tom["Miền"].str.upper().isin(["TOÀN QUỐC","TOTAL","TỔNG CỘNG","GRAND TOTAL"])]

    tong_diem  = int(mien_data["TongDiem"].sum())
    tong_ban   = int(mien_data["DiemBan"].sum())
    tong_sl    = int(mien_data["SanLuong"].sum())
    bao_phu    = tong_ban / tong_diem if tong_diem else 0
    sl_bq      = tong_sl / tong_ban   if tong_ban  else 0
    dat_kpi    = int((mien_data["DatKPI"] == "Đạt").sum())
    tong_ml    = int(mien_data["DiemMuaLai"].sum())
    tl_ml      = tong_ml / tong_ban if tong_ban else 0

    c1,c2,c3,c4 = st.columns(4)
    with c1: st.markdown(f'<div class="metric-card"><div class="metric-label">Tổng điểm quản lý</div><div class="metric-value">{tong_diem:,}</div><div class="metric-sub">điểm bán</div></div>', unsafe_allow_html=True)
    with c2: st.markdown(f'<div class="metric-card warn"><div class="metric-label">Điểm đã bán Yett</div><div class="metric-value">{tong_ban:,}</div><div class="metric-sub">Bao phủ {bao_phu:.1%}</div></div>', unsafe_allow_html=True)
    with c3: st.markdown(f'<div class="metric-card good"><div class="metric-label">Sản lượng Yett</div><div class="metric-value">{tong_sl:,}</div><div class="metric-sub">SLBQ {sl_bq:.1f} gói/điểm</div></div>', unsafe_allow_html=True)
    with c4: st.markdown(f'<div class="metric-card info"><div class="metric-label">Điểm mua lại (≥2 lần)</div><div class="metric-value">{tong_ml:,}</div><div class="metric-sub">Tỷ lệ {tl_ml:.2%}</div></div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown('<div class="section-title">Chi tiết theo Miền</div>', unsafe_allow_html=True)

    # Table
    display = mien_data.copy()
    display["TyLeBaoPhu"] = display["TyLeBaoPhu"].map(lambda x: f"{x:.1%}")
    display["SLBQ"] = display["SLBQ"].map(lambda x: f"{x:.2f}")
    display["TyLeMuaLai"] = display["TyLeMuaLai"].map(lambda x: f"{x:.2%}")
    display["DatKPI"] = display["DatKPI"].map(lambda x:
        f'<span class="kpi-badge-dat">✅ Đạt</span>' if x=="Đạt"
        else f'<span class="kpi-badge-chua">❌ Chưa đạt</span>')
    display = display.rename(columns={
        "Miền":"Miền","TongDiem":"Tổng điểm QL","DiemBan":"Điểm bán Yett",
        "TyLeBaoPhu":"Bao phủ %","DatKPI":"KPI ≥30%",
        "SanLuong":"Sản lượng","SLBQ":"SLBQ/điểm",
        "DiemMuaLai":"Điểm mua lại","TyLeMuaLai":"Tỷ lệ mua lại"
    })
    st.write(display.to_html(escape=False, index=False), unsafe_allow_html=True)

    # Charts
    st.markdown("<br>", unsafe_allow_html=True)
    ch1, ch2 = st.columns(2)
    with ch1:
        fig = px.bar(mien_data, x="Miền", y="DiemBan", color="DatKPI",
                     color_discrete_map={"Đạt":"#0e9f6e","Chưa đạt":"#e3a008"},
                     title="Điểm đã bán Yett theo Miền",
                     labels={"DiemBan":"Điểm bán","DatKPI":"KPI"})
        fig.update_layout(showlegend=True, plot_bgcolor="white", height=320, margin=dict(t=40,b=20))
        fig.add_hline(y=0, line_dash="dot")
        st.plotly_chart(fig, use_container_width=True)
    with ch2:
        fig2 = px.bar(mien_data, x="Miền", y="TyLeBaoPhu",
                      title="Tỷ lệ bao phủ (%) theo Miền",
                      labels={"TyLeBaoPhu":"Bao phủ %"},
                      color_discrete_sequence=["#1a56db"])
        fig2.add_hline(y=0.3, line_dash="dash", line_color="red",
                       annotation_text="Mốc KPI 30%", annotation_position="top right")
        fig2.update_yaxes(tickformat=".0%")
        fig2.update_layout(plot_bgcolor="white", height=320, margin=dict(t=40,b=20))
        st.plotly_chart(fig2, use_container_width=True)

# ════════════════════════════════════════════════════════════════════════════
# TAB 2 – Miền – Tỉnh
# ════════════════════════════════════════════════════════════════════════════
with tab2:
    df_mien.columns = ["Miền","Tinh","SoNVTT","TongDiem","DiemBan","TyLe","DatKPI","SanLuong","SLBQ","TyLeMuaLai","NgayBatDau"][:len(df_mien.columns)]

    # Filters
    f1,f2,f3 = st.columns([2,2,2])
    mien_opts = ["Tất cả"] + sorted(df_mien["Miền"].dropna().unique().tolist())
    with f1: sel_mien = st.selectbox("Miền", mien_opts)
    kpi_opts = ["Tất cả", "Đạt", "Chưa đạt"]
    with f2: sel_kpi  = st.selectbox("KPI", kpi_opts)

    filt = df_mien.copy()
    if sel_mien != "Tất cả": filt = filt[filt["Miền"]==sel_mien]
    if sel_kpi  != "Tất cả": filt = filt[filt["DatKPI"]==sel_kpi]

    st.markdown(f"**{len(filt)} tỉnh thành**")

    # Format
    show = filt.copy()
    for col in ["TyLe","TyLeMuaLai"]:
        if col in show.columns:
            show[col] = show[col].map(lambda x: f"{x:.1%}" if pd.notnull(x) else "")
    if "SLBQ" in show.columns:
        show["SLBQ"] = show["SLBQ"].map(lambda x: f"{x:.2f}" if pd.notnull(x) else "")
    if "NgayBatDau" in show.columns:
        show["NgayBatDau"] = pd.to_datetime(show["NgayBatDau"]).dt.strftime("%d/%m/%Y").fillna("")
    if "DatKPI" in show.columns:
        show["DatKPI"] = show["DatKPI"].map(lambda x:
            '✅ Đạt' if x=="Đạt" else '❌ Chưa đạt')

    show = show.rename(columns={
        "Miền":"Miền","Tinh":"Tỉnh","SoNVTT":"NVTT","TongDiem":"Tổng điểm QL",
        "DiemBan":"Điểm bán","TyLe":"Bao phủ %","DatKPI":"KPI",
        "SanLuong":"Sản lượng","SLBQ":"SLBQ/điểm","TyLeMuaLai":"Tỷ lệ mua lại",
        "NgayBatDau":"Ngày bắt đầu bán"
    })
    st.dataframe(show, use_container_width=True, height=480, hide_index=True)

    # Bar chart by province
    if len(filt) > 0:
        fig3 = px.bar(filt.sort_values("TyLe",ascending=False),
                      x="Tinh", y="TyLe", color="DatKPI",
                      color_discrete_map={"Đạt":"#0e9f6e","Chưa đạt":"#e3a008"},
                      title="Tỷ lệ bao phủ theo Tỉnh",
                      labels={"TyLe":"Bao phủ %","Tinh":"Tỉnh","DatKPI":"KPI"})
        fig3.add_hline(y=0.3,line_dash="dash",line_color="red",
                       annotation_text="KPI 30%",annotation_position="top right")
        fig3.update_yaxes(tickformat=".0%")
        fig3.update_layout(plot_bgcolor="white",height=380,
                           xaxis_tickangle=-35,margin=dict(t=40,b=80))
        st.plotly_chart(fig3, use_container_width=True)

# ════════════════════════════════════════════════════════════════════════════
# TAB 3 – Theo NVTT
# ════════════════════════════════════════════════════════════════════════════
with tab3:
    rename_nvtt = {
        df_nvtt.columns[0]:"MaNVTT", df_nvtt.columns[1]:"TenNVTT",
        df_nvtt.columns[2]:"Mien",   df_nvtt.columns[3]:"Tinh",
        df_nvtt.columns[4]:"TongDiem",df_nvtt.columns[5]:"DiemBan",
        df_nvtt.columns[6]:"TyLe",   df_nvtt.columns[7]:"DatKPI",
        df_nvtt.columns[8]:"SanLuong",df_nvtt.columns[9]:"SLBQ",
        df_nvtt.columns[10]:"DiemL1",df_nvtt.columns[11]:"DiemL2",
        df_nvtt.columns[12]:"TyLeMuaLai",
    }
    df_n = df_nvtt.rename(columns=rename_nvtt)

    # Summary cards
    total_nvtt = len(df_n)
    nvtt_dat   = int((df_n["DatKPI"]=="Đạt").sum())
    nvtt_zero  = int((df_n["DiemBan"]==0).sum())
    c1,c2,c3 = st.columns(3)
    with c1: st.markdown(f'<div class="metric-card"><div class="metric-label">Tổng NVTT</div><div class="metric-value">{total_nvtt:,}</div></div>', unsafe_allow_html=True)
    with c2: st.markdown(f'<div class="metric-card good"><div class="metric-label">NVTT đạt KPI (≥30%)</div><div class="metric-value">{nvtt_dat}</div><div class="metric-sub">{nvtt_dat/total_nvtt:.1%} tổng NVTT</div></div>', unsafe_allow_html=True)
    with c3: st.markdown(f'<div class="metric-card warn"><div class="metric-label">NVTT chưa bán điểm nào</div><div class="metric-value">{nvtt_zero}</div><div class="metric-sub">{nvtt_zero/total_nvtt:.1%} tổng NVTT</div></div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Filters
    f1,f2,f3,f4 = st.columns([2,2,2,2])
    with f1: sm = st.selectbox("Miền", ["Tất cả"]+sorted(df_n["Mien"].dropna().unique().tolist()), key="nv_mien")
    df_nt = df_n if sm=="Tất cả" else df_n[df_n["Mien"]==sm]
    with f2: st2 = st.selectbox("Tỉnh", ["Tất cả"]+sorted(df_nt["Tinh"].dropna().unique().tolist()), key="nv_tinh")
    df_nt = df_nt if st2=="Tất cả" else df_nt[df_nt["Tinh"]==st2]
    with f3: sk = st.selectbox("KPI", ["Tất cả","Đạt","Chưa đạt"], key="nv_kpi")
    df_nt = df_nt if sk=="Tất cả" else df_nt[df_nt["DatKPI"]==sk]
    with f4: search = st.text_input("🔍 Tìm NVTT", placeholder="Nhập tên...")
    if search: df_nt = df_nt[df_nt["TenNVTT"].str.contains(search, case=False, na=False)]

    st.markdown(f"**{len(df_nt)} NVTT**")

    show_n = df_nt.copy()
    show_n["TyLe"] = show_n["TyLe"].map(lambda x: f"{x:.1%}")
    show_n["SLBQ"] = show_n["SLBQ"].map(lambda x: f"{x:.2f}" if pd.notnull(x) else "")
    show_n["TyLeMuaLai"] = show_n["TyLeMuaLai"].map(lambda x: f"{x:.2%}")
    show_n["DatKPI"] = show_n["DatKPI"].map(lambda x: "✅ Đạt" if x=="Đạt" else "❌ Chưa đạt")
    show_n = show_n.rename(columns={
        "MaNVTT":"Mã","TenNVTT":"Tên NVTT","Mien":"Miền","Tinh":"Tỉnh",
        "TongDiem":"Điểm QL","DiemBan":"Điểm bán","TyLe":"Bao phủ %","DatKPI":"KPI",
        "SanLuong":"Sản lượng","SLBQ":"SLBQ/điểm","DiemL1":"Lần 1","DiemL2":"Lần ≥2","TyLeMuaLai":"Tỷ lệ mua lại"
    })
    st.dataframe(show_n, use_container_width=True, height=440, hide_index=True)

    # Breakdown chart: phân loại NVTT theo bao phủ
    st.markdown('<div class="section-title">Phân loại NVTT theo mức bao phủ</div>', unsafe_allow_html=True)
    bins   = [-0.001,0,0.099,0.199,0.299,1.1]
    labels = ["0% (chưa bán)","0–10%","10–20%","20–30%","≥30% (Đạt KPI)"]
    df_n2  = df_nt.copy()
    df_n2["Nhóm"] = pd.cut(df_n2["TyLe"].astype(float), bins=bins, labels=labels)
    grp = df_n2["Nhóm"].value_counts().reindex(labels).reset_index()
    grp.columns = ["Nhóm","Số NVTT"]
    colors = ["#d1d5db","#fde68a","#fcd34d","#fb923c","#0e9f6e"]
    fig4 = px.bar(grp, x="Nhóm", y="Số NVTT", color="Nhóm",
                  color_discrete_sequence=colors, title="Phân bố NVTT theo tỷ lệ bao phủ")
    fig4.update_layout(showlegend=False, plot_bgcolor="white", height=300, margin=dict(t=40,b=20))
    st.plotly_chart(fig4, use_container_width=True)

# ════════════════════════════════════════════════════════════════════════════
# TAB 4 – Thống kê Mua lại
# ════════════════════════════════════════════════════════════════════════════
with tab4:
    df_ml = df_mualai.copy()
    # Summary
    tong_diem_ml = len(df_ml)
    phan_loai    = df_ml["Phân loại"].value_counts() if "Phân loại" in df_ml.columns else pd.Series(dtype=int)
    l1 = int(phan_loai.get("Lần 1",0))
    l2 = int(phan_loai.get("Lần 2",0))
    l3p= int(sum(v for k,v in phan_loai.items() if "3" in str(k) or (k not in ("Lần 1","Lần 2"))))

    c1,c2,c3,c4 = st.columns(4)
    with c1: st.markdown(f'<div class="metric-card"><div class="metric-label">Tổng điểm bán Yett</div><div class="metric-value">{tong_diem_ml:,}</div></div>', unsafe_allow_html=True)
    with c2: st.markdown(f'<div class="metric-card warn"><div class="metric-label">Mua lần 1</div><div class="metric-value">{l1:,}</div><div class="metric-sub">{l1/tong_diem_ml:.1%}</div></div>', unsafe_allow_html=True)
    with c3: st.markdown(f'<div class="metric-card info"><div class="metric-label">Mua lần 2</div><div class="metric-value">{l2:,}</div><div class="metric-sub">{l2/tong_diem_ml:.1%}</div></div>', unsafe_allow_html=True)
    with c4: st.markdown(f'<div class="metric-card good"><div class="metric-label">Mua lần 3+</div><div class="metric-value">{l3p:,}</div><div class="metric-sub">{l3p/tong_diem_ml:.1%}</div></div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    ch1,ch2 = st.columns([1,2])
    with ch1:
        pie_data = phan_loai.reset_index()
        pie_data.columns = ["Phân loại","Số điểm"]
        fig5 = px.pie(pie_data, names="Phân loại", values="Số điểm",
                      title="Tỷ lệ điểm theo số lần mua",
                      color_discrete_sequence=["#6b7280","#1a56db","#0e9f6e","#7e3af2"])
        fig5.update_layout(height=300,margin=dict(t=40,b=10,l=0,r=0))
        st.plotly_chart(fig5, use_container_width=True)
    with ch2:
        if "Ngày mua đầu tiên_DMS" in df_ml.columns:
            df_ml["NgayMua"] = pd.to_datetime(df_ml["Ngày mua đầu tiên_DMS"], errors="coerce").dt.date
            ts = df_ml.groupby("NgayMua").size().reset_index(name="Số điểm mới")
            ts["Lũy kế"] = ts["Số điểm mới"].cumsum()
            fig6 = go.Figure()
            fig6.add_trace(go.Bar(x=ts["NgayMua"].astype(str), y=ts["Số điểm mới"],
                                  name="Điểm mới/ngày", marker_color="#93c5fd"))
            fig6.add_trace(go.Scatter(x=ts["NgayMua"].astype(str), y=ts["Lũy kế"],
                                      name="Lũy kế", line=dict(color="#1a56db",width=2.5),
                                      yaxis="y2"))
            fig6.update_layout(title="Điểm bán theo ngày (lũy kế)",
                               yaxis=dict(title="Điểm mới"),
                               yaxis2=dict(title="Lũy kế",overlaying="y",side="right"),
                               plot_bgcolor="white",height=300,
                               margin=dict(t=40,b=20),legend=dict(orientation="h",y=1.1))
            st.plotly_chart(fig6, use_container_width=True)

    # Filters + table
    f1,f2 = st.columns([2,2])
    with f1:
        ml_mien = st.selectbox("Miền", ["Tất cả"]+sorted(df_ml["Miền"].dropna().unique().tolist()) if "Miền" in df_ml.columns else ["Tất cả"], key="ml_mien")
    with f2:
        ml_pl   = st.selectbox("Phân loại", ["Tất cả"]+sorted(phan_loai.index.tolist()), key="ml_pl")
    filt_ml = df_ml.copy()
    if ml_mien != "Tất cả": filt_ml = filt_ml[filt_ml["Miền"]==ml_mien]
    if ml_pl   != "Tất cả": filt_ml = filt_ml[filt_ml["Phân loại"]==ml_pl]

    st.markdown(f"**{len(filt_ml):,} điểm bán**")
    if "Ngày mua đầu tiên_DMS" in filt_ml.columns:
        filt_ml["Ngày mua đầu tiên_DMS"] = pd.to_datetime(filt_ml["Ngày mua đầu tiên_DMS"], errors="coerce").dt.strftime("%d/%m/%Y %H:%M")
    st.dataframe(filt_ml, use_container_width=True, height=380, hide_index=True)

# ── Footer ────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown('<div style="text-align:center;color:#9ca3af;font-size:12px">Dashboard tự động từ file Excel export — upload file mới để cập nhật dữ liệu</div>', unsafe_allow_html=True)
